from kaggle_environments.envs.football.helpers import *
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import pickle
import math


import tensorflow as tf

# load the models from disk
filename = '/kaggle_simulations/agent/saved_model/random_forest.sav'
random_forest = pickle.load(open(filename, 'rb'))

filename = '/kaggle_simulations/agent/saved_model/should_kick.h5'
pred_should_kick = tf.keras.models.load_model(filename)
pred_should_kick.compile(optimizer='adam',
        loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=['accuracy'])

filename = '/kaggle_simulations/agent/saved_model/model.h5'
loaded_model = tf.keras.models.load_model(filename)
loaded_model.compile(optimizer='adam',
        loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
        metrics=['accuracy'])


directions = [[Action.TopLeft, Action.Top, Action.TopRight],
[Action.Left, Action.Idle, Action.Right],
[Action.BottomLeft, Action.Bottom, Action.BottomRight]]

#track raw data to troubleshoot...
track_raw_data=[]

perfectRange = [[0.7, 0.95], [-0.12, 0.12]]
outerRange1 = [[0.8, 1.0], [-0.42, -0.3]]
outerRange2 = [[0.8, 1.0], [0.3, 0.42]]

nearRange1 = [[0.85, 1.0], [-0.3, -0.2]]
nearRange2 = [[0.85, 1.0], [0.2, 0.3]]

def inside(pos, area):
    return area[0][0] <= pos[0] <= area[0][1] and area[1][0] <= pos[1] <= area[1][1]

def get_distance(pos1,pos2):
    return ((pos1[0]-pos2[0])**2+(pos1[1]-pos2[1])**2)**0.5

def get_heading(pos1,pos2):
    raw_head=math.atan2(pos1[0]-pos2[0],pos1[1]-pos2[1])/math.pi*180

    if raw_head<0:
        head=360+raw_head
    else:
        head=raw_head
    return head

def get_action(action_num):
    if action_num==0:
        return Action.Idle
    if action_num==1:
        return Action.Left
    if action_num==2:
        return Action.TopLeft
    if action_num==3:
        return Action.Top
    if action_num==4:
        return Action.TopRight
    if action_num==5:
        return Action.Right
    if action_num==6:
        return Action.BottomRight
    if action_num==7:
        return Action.Bottom
    if action_num==8:
        return Action.BottomLeft
    if action_num==9:
        return Action.LongPass
    if action_num==10:
        return Action.HighPass
    if action_num==11:
        return Action.ShortPass
    if action_num==12:
        return Action.Shot
    if action_num==13:
        return Action.Sprint
    if action_num==14:
        return Action.ReleaseDirection
    if action_num==15:
        return Action.ReleaseSprint
    if action_num==16:
        #return Action.Sliding
        return Action.Idle
    if action_num==17:
        return Action.Dribble
    if action_num==18:
        #return Action.ReleaseDribble
        return Action.Idle
    return Action.Right

@human_readable_agent
def agent(obs):

    
    controlled_player_pos = obs['left_team'][obs['active']]
    x = controlled_player_pos[0]
    y = controlled_player_pos[1]
    pactive=obs['active']
    
    if obs["game_mode"] == GameMode.Penalty:
        return Action.Shot
    if obs["game_mode"] == GameMode.Corner:
        if controlled_player_pos[0] > 0:
            return Action.Shot
    if obs["game_mode"] == GameMode.FreeKick:
        return Action.Shot
    
    # Make sure player is running.
    if  0 < controlled_player_pos[0] < 0.6 and Action.Sprint not in obs['sticky_actions']:
        return Action.Sprint
    elif 0.6 < controlled_player_pos[0] and Action.Sprint in obs['sticky_actions']:
        return Action.ReleaseSprint
    
    #if we have the ball
    if obs['ball_owned_player'] == obs['active'] and obs['ball_owned_team'] == 0:
        dat=[]
        
        to_append=[]
        to_append1= []
        #return Action.Right
        #get controller player pos
        controlled_player_pos = obs['left_team'][obs['active']]

        if inside(controlled_player_pos, perfectRange) and controlled_player_pos[0] < obs['ball'][0]:
            return Action.Shot

        if ((inside(controlled_player_pos, nearRange1) or inside(controlled_player_pos, nearRange2)) and controlled_player_pos[0] < obs['ball'][0]):
            return Action.ShortPass

        if (obs['active'] < 4 and controlled_player_pos[0] > 0.0 and controlled_player_pos[0] < obs['ball'][0]):
            return Action.ShortPass

        front_most = 0
        behind_most = 0
        front_y = 0
        behind_y = 0

        closePlayer = 0

        for i in range(len(obs['left_team'])):
            if (i != obs['active']):
                player = obs['left_team'][i]
                if (player[0] > front_most):
                    front_most = player[0]
                    front_y = player[1]
        
        for i in range(len(obs['right_team'])):
            if (i != 0):
                player = obs['right_team'][i]
                d = get_distance(controlled_player_pos, player)
                if (d < 0.05):
                    closePlayer += 1
                if (player[0] > behind_most):
                    behind_most = player[0]
                    behind_y = player[1]
        
        if (controlled_player_pos[0] < -0.7 and closePlayer >= 2 and controlled_player_pos[0] < obs['ball'][0]):
            return Action.LongPass
        
        if ((front_most - controlled_player_pos[0]) > 0.1 and behind_most > 0.5 and (behind_most > front_most) and (behind_most - front_most) < 0.15 and abs(behind_y - front_y) > 0.1):
            return Action.HighPass
        
        goalx=0.0
        goaly=0.0

        sidelinex=0.0
        sideliney=0.42

        to_append.append(x)
        to_append.append(y)
        
        goal_dist=get_distance((x,y),(goalx,goaly))
        sideline_dist=get_distance((x,y),(sidelinex,sideliney))
        to_append.append(goal_dist)
        to_append.append(sideline_dist)
        to_append1.append(goal_dist)
        to_append1.append(sideline_dist)
        
        for i in range(len(obs['left_team'])):
            dist=get_distance((x,y),(obs['left_team'][i][0],obs['left_team'][i][1]))
            head=get_heading((x,y),(obs['left_team'][i][0],obs['left_team'][i][1]))
            to_append.append(dist)
            to_append.append(head)
            to_append1.append(dist)
            to_append1.append(head)
        
        for i in range(len(obs['right_team'])):
            dist=get_distance((x,y),(obs['right_team'][i][0],obs['right_team'][i][1]))
            head=get_heading((x,y),(obs['right_team'][i][0],obs['right_team'][i][1]))
            to_append.append(dist)
            to_append.append(head)
            to_append1.append(dist)
            to_append1.append(head)
        
        
        if (len(obs['sticky_actions']) != 10):
            dat1 = []
            dat1.append(to_append1)
            predictions=loaded_model.predict(dat1)
            predicted_action = np.argmax(predictions[0])
            do=get_action(predicted_action)
            if do == None:
                return Action.Right
            else:
                return do


        for i in range(10):
            to_append.append(obs['sticky_actions'][i])
        
        dat.append(to_append)
        dat1 = []
        dat1.append(to_append1)
        
        kick_pred = pred_should_kick.predict(dat)
        kick_pred = np.argmax(kick_pred[0])
        
        if kick_pred == 0:
            predicted = random_forest.predict(dat)
            predicted_action = np.argmax(predicted[0])
        else:
            predicted_action = kick_pred + 8
        
        
        do=get_action(predicted_action)
        
        
        if do == None:
            return Action.Right
        else:
            return do
    
    # if we don't have ball run to ball
    else:
        
        dirsign = lambda x: 1 if abs(x) < 0.01 else (0 if x < 0 else 2)
        #where ball is going
        ball_targetx=obs['ball'][0]+(obs['ball_direction'][0]*5)
        ball_targety=obs['ball'][1]+(obs['ball_direction'][1]*5)
        
        e_dist=get_distance(obs['left_team'][obs['active']],obs['ball'])
        
        if e_dist >.01:
            # Run where ball will be
            xdir = dirsign(ball_targetx - controlled_player_pos[0])
            ydir = dirsign(ball_targety - controlled_player_pos[1])
            return directions[ydir][xdir]
        else:
            # Run towards the ball.
            xdir = dirsign(obs['ball'][0] - controlled_player_pos[0])
            ydir = dirsign(obs['ball'][1] - controlled_player_pos[1])
            return directions[ydir][xdir]
